import React, { Component } from 'react';

class Loading extends Component {
  render() {
    return (
      <div>Carregando...</div>
    );
  }
}

export default Loading;
